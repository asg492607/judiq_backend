# Core domain contract package
