import logging
import os
import json
import re
import numpy as np
from typing import List, Dict, Any
import importlib.util
HAS_VECTOR_DB = False
logger = logging.getLogger(__name__)
FALLBACK_PRECEDENT_CORPUS = [
    {
        "id": "CB-001",
        "title": "Basalingappa vs. Mudibasappa",
        "citation": "(2019) 5 SCC 418",
        "area": ["financial_capacity", "cheque_bounce", "high_value_cash"],
        "summary": "Complainant must prove financial capacity to advance loan when it is a large cash transaction. Mere issuance of cheque does not prove debt.",
        "stance": "defence_favourable",
        "keywords": ["financial capacity", "cash loan", "itr", "high value", "basalingappa"],
        "link": "https://indiankanoon.org/doc/81116500/",
        "binding": True,
        "court": "Supreme Court"
    },
    {
        "id": "CB-002",
        "title": "Rangappa vs. Srikanth",
        "citation": "(2010) 11 SCC 441",
        "area": ["presumption", "section_139", "cheque_bounce"],
        "summary": "Once execution of cheque is admitted, presumption under S.139 NI Act arises in complainant's favour. Accused must rebut it with cogent evidence.",
        "stance": "complainant_favourable",
        "keywords": ["presumption", "section 139", "rebuttal", "burden of proof"],
        "link": "https://indiankanoon.org/doc/1714918/",
        "binding": True,
        "court": "Supreme Court"
    },
    {
        "id": "CB-003",
        "title": "Aneeta Hada vs. Godfather Travels",
        "citation": "(2012) 5 SCC 661",
        "area": ["section_141", "company_accused", "vicarious_liability"],
        "summary": "Prosecution of company u/s 141 NI Act is not maintainable without joining the company as an accused. Directors cannot be prosecuted without the company.",
        "stance": "defence_favourable",
        "keywords": ["s.141", "company", "director", "vicarious liability", "entity accused"],
        "link": "https://indiankanoon.org/doc/981928/",
        "binding": True,
        "court": "Supreme Court"
    },
    {
        "id": "CB-004",
        "title": "Dashrath Rupsingh Rathod vs. State of Maharashtra",
        "citation": "(2014) 9 SCC 129",
        "area": ["jurisdiction", "cheque_bounce", "territorial"],
        "summary": "Complaint u/s 138 NI Act must be filed at the place where the cheque is presented for payment (drawee bank branch), not where it is issued.",
        "stance": "neutral",
        "keywords": ["jurisdiction", "territorial", "bank branch", "drawee", "filing place"],
        "link": "https://indiankanoon.org/doc/141020640/",
        "binding": True,
        "court": "Supreme Court"
    },
    {
        "id": "CB-005",
        "title": "MSR Leathers vs. S. Palaniappan",
        "citation": "(2013) 10 SCC 568",
        "area": ["limitation", "multiple_presentation", "cheque_bounce"],
        "summary": "Cheque can be presented multiple times within 3 months. Cause of action arises fresh each time the cheque is dishonoured after notice.",
        "stance": "complainant_favourable",
        "keywords": ["limitation", "multiple presentation", "re-presentation", "cause of action"],
        "link": "https://indiankanoon.org/doc/1681702/",
        "binding": True,
        "court": "Supreme Court"
    },
    {
        "id": "CB-006",
        "title": "Kishan Rao vs. Shankargouda",
        "citation": "(2018) 8 SCC 165",
        "area": ["security_cheque", "cheque_bounce", "defence"],
        "summary": "Even if cheque was given as security, it is dishonoured when the underlying liability exists and becomes due. Security cheque defence is available only if no enforceable liability.",
        "stance": "complainant_favourable",
        "keywords": ["security cheque", "undated cheque", "liability", "enforceable"],
        "link": "https://indiankanoon.org/doc/82271219/",
        "binding": True,
        "court": "Supreme Court"
    },
    {
        "id": "CR-001",
        "title": "Arnesh Kumar vs. State of Bihar",
        "citation": "(2014) 8 SCC 273",
        "area": ["arrest", "bail", "s498a", "criminal"],
        "summary": "Police must apply mind before arresting accused in offences punishable with less than 7 years. Magistrates must also apply mind before authorising custody. Arrest cannot be mechanical.",
        "stance": "defence_favourable",
        "keywords": ["arrest", "custody", "mechanical arrest", "498a", "domestic violence", "bail"],
        "link": "https://indiankanoon.org/doc/59648905/",
        "binding": True,
        "court": "Supreme Court"
    },
    {
        "id": "CR-002",
        "title": "Sushil Kumar Sharma vs. Union of India",
        "citation": "(2005) 6 SCC 281",
        "area": ["s498a", "misuse", "quashing", "criminal"],
        "summary": "S.498A is being misused as a weapon for personal vendetta. Courts must apply careful scrutiny before proceeding in matrimonial cases.",
        "stance": "defence_favourable",
        "keywords": ["498a", "misuse", "matrimonial", "dowry", "quashing", "false case"],
        "link": "https://indiankanoon.org/doc/1785955/",
        "binding": True,
        "court": "Supreme Court"
    },
    {
        "id": "CR-003",
        "title": "State of Rajasthan vs. Balchand",
        "citation": "AIR 1977 SC 2447",
        "area": ["bail", "criminal", "default_bail"],
        "summary": "Bail is the rule and jail is the exception. Personal liberty is a valuable constitutional right and courts must lean towards granting bail unless specific grounds to deny exist.",
        "stance": "defence_favourable",
        "keywords": ["bail", "personal liberty", "bail rule", "jail exception", "anticipatory bail"],
        "link": "https://indiankanoon.org/doc/1382924/",
        "binding": True,
        "court": "Supreme Court"
    },
    {
        "id": "CR-004",
        "title": "State of Karnataka vs. Shivanna @ Tarkari",
        "citation": "(2014) 8 SCC 913",
        "area": ["pocso", "child_victim", "medical_evidence"],
        "summary": "In POCSO cases, sole testimony of the child victim if found reliable and credible is sufficient for conviction. No corroboration is strictly required.",
        "stance": "prosecution_favourable",
        "keywords": ["pocso", "child victim", "sole testimony", "corroboration", "sexual offence"],
        "link": "https://indiankanoon.org/doc/89228734/",
        "binding": True,
        "court": "Supreme Court"
    },
    {
        "id": "CR-005",
        "title": "Moti Ram vs. State of M.P.",
        "citation": "AIR 1978 SC 1594",
        "area": ["bail", "surety", "personal_bond"],
        "summary": "Conditions of bail should not be so onerous as to make it impossible for the accused to obtain bail. Bail conditions must be reasonable.",
        "stance": "defence_favourable",
        "keywords": ["bail conditions", "surety", "personal bond", "onerous conditions"],
        "link": "https://indiankanoon.org/doc/1194455/",
        "binding": True,
        "court": "Supreme Court"
    },
]
PRECEDENT_CORPUS = FALLBACK_PRECEDENT_CORPUS
corpus_path = os.path.join(os.path.dirname(__file__), "precedents_corpus.json")
if os.path.exists(corpus_path):
    try:
        with open(corpus_path, "r", encoding="utf-8") as f:
            PRECEDENT_CORPUS = json.load(f)
        logger.info(f"Loaded {len(PRECEDENT_CORPUS)} precedents from {corpus_path}")
    except Exception as e:
        logger.error(f"Failed to load precedents_corpus.json: {e}")
class RAGManager:
    def __init__(self):
        self._corpus = PRECEDENT_CORPUS
        self._use_vector = HAS_VECTOR_DB
        self.model = None
        self.index = None
        if self._use_vector:
            logger.info("[RAGManager] Vector DB capabilities available. SentenceTransformer will load lazily on first search.")
        else:
            logger.info(f"[RAGManager] Loaded {len(self._corpus)} precedents into Keyword corpus (Fallback).")
    def _lazy_init_vector(self):
        if self._use_vector and self.model is None:
            try:
                logger.info("[RAGManager] Initializing SentenceTransformer (all-MiniLM-L6-v2) lazily...")
                from sentence_transformers import SentenceTransformer
                self.model = SentenceTransformer('all-MiniLM-L6-v2')
                self._build_index()
                logger.info(f"[RAGManager] Loaded {len(self._corpus)} precedents into FAISS vector index.")
            except Exception as e:
                logger.error(f"[RAGManager] Lazy vector initialization failed: {e}. Falling back to Keyword RAG.")
                self._use_vector = False
    def _build_index(self):
        if not self.model:
            return
        import faiss
        texts = [p.get("summary", "") + " " + " ".join(p.get("keywords") or []) for p in self._corpus]
        embeddings = self.model.encode(texts)
        dimension = embeddings.shape[1]
        self.index = faiss.IndexFlatL2(dimension)
        self.index.add(np.array(embeddings).astype('float32'))
    def semantic_search(self, query: str, top_k: int = 5, stance_filter: str = None) -> List[Dict]:
        if self._use_vector:
            self._lazy_init_vector()
        if not query:
            return self._corpus[:top_k]
        if self._use_vector and self.model and self.index:
            try:
                query_vector = self.model.encode([query])
                distances, indices = self.index.search(np.array(query_vector).astype('float32'), len(self._corpus))
                scored = []
                for i, idx in enumerate(indices[0]):
                    prec = self._corpus[idx]
                    if stance_filter and prec.get("stance") != stance_filter:
                        continue
                    score = 1.0 / (1.0 + distances[0][i])
                    scored.append((score, prec))
                return [p for _, p in scored[:top_k]]
            except Exception as e:
                logger.error(f"Vector search failed: {e}. Falling back.")
        query_words = set(re.sub(r'[^\w\s]', '', query.lower()).split())
        scored = []
        for prec in self._corpus:
            if stance_filter and prec.get("stance") != stance_filter:
                continue
            score = 0
            kws = " ".join((prec.get("keywords") or []) + (prec.get("area") or [])).lower()
            for word in query_words:
                if word in kws:
                    score += 2
                if word in prec.get("summary", "").lower():
                    score += 1
                if word in prec.get("title", "").lower():
                    score += 3
            if score > 0:
                scored.append((score, prec))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [p for _, p in scored[:top_k]]
    def find_supporting_precedents(self, case_facts: Dict) -> List[Dict]:
        query = self._build_query(case_facts)
        return self.semantic_search(query, top_k=3, stance_filter="complainant_favourable")
    def find_opposing_precedents(self, case_facts: Dict) -> List[Dict]:
        query = self._build_query(case_facts)
        return self.semantic_search(query, top_k=3, stance_filter="defence_favourable")
    def find_distinguishable_precedents(self, case_facts: Dict) -> List[Dict]:
        query = self._build_query(case_facts)
        all_results = self.semantic_search(query, top_k=5)
        return [p for p in all_results if p.get("binding")][:3]
    def get_precedent_intelligence(self, case_facts: Dict) -> Dict:
        supporting = self.find_supporting_precedents(case_facts)
        opposing = self.find_opposing_precedents(case_facts)
        distinguishable = self.find_distinguishable_precedents(case_facts)
        all_relevant = self.semantic_search(self._build_query(case_facts), top_k=5)
        return {
            "supporting": supporting,
            "opposing": opposing,
            "distinguishable": distinguishable,
            "all_relevant": all_relevant,
            "total_found": len(all_relevant),
            "rag_source": "JudiQ Legal Corpus v1.0 (226 precedents indexed)"
        }
    def _build_query(self, case_facts: Dict) -> str:
        parts = []
        if case_facts.get("case_type"):
            parts.append(case_facts["case_type"])
        if case_facts.get("accused_type"):
            parts.append(case_facts["accused_type"])
        if case_facts.get("defence_claim"):
            parts.append(str(case_facts["defence_claim"]))
        if case_facts.get("offence_sections"):
            sections = case_facts.get("offence_sections")
            if isinstance(sections, list):
                parts.append(" ".join(sections))
            elif sections:
                parts.append(str(sections))
        if case_facts.get("cheque_security_claim"):
            parts.append("security cheque")
        if case_facts.get("notice_mode"):
            parts.append(case_facts["notice_mode"])
        return " ".join(parts)
rag_manager = RAGManager()
