"""
Root shim module for backward compatibility.
Delegates to backend.criminal package.
"""

from criminal.router import router, CriminalAnalysisRequest, BailAssessmentRequest, analyze_criminal_case, evaluate_bail, evaluate_quashing
from criminal.criminal_engine import CriminalEngine
from criminal.criminal_scoring_engine import CriminalScoringEngine
from criminal.criminal_adversarial_engine import CriminalAdversarialEngine
from criminal.criminal_rules_engine import CriminalRulesEngine
from criminal.criminal_timeline_engine import CriminalTimelineEngine
from criminal.criminal_economics_engine import CriminalEconomicsEngine

__all__ = [
    "router",
    "CriminalAnalysisRequest",
    "BailAssessmentRequest",
    "analyze_criminal_case",
    "evaluate_bail",
    "evaluate_quashing",
    "CriminalEngine",
    "CriminalScoringEngine",
    "CriminalAdversarialEngine",
    "CriminalRulesEngine",
    "CriminalTimelineEngine",
    "CriminalEconomicsEngine"
]
